#pragma once
#define		ERROR_OK				1		//no error happen
#define		ERROR_VM_NOEXIST		2
#define		ERROR_SYSSUP_FAIL		3
#define		ERROR_LOADSUP_FAIL	4
#define		ERROR_SYSINODE_FAIL	5
#define		ERROR_BWRITE_FAIL		6
#define		ERROR_BREAD_FAIL		7
#define		ERROR_BLOCK_EMPTY		-1